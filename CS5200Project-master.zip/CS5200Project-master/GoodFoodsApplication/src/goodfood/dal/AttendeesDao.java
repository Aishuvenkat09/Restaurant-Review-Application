package goodfood.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import goodfood.model.Attendees;
import goodfood.model.Attendees.Attending;

/**
 * @Date : Nov 9, 2019
 *
 * @Author: Divyavijay Sahay
 */

public class AttendeesDao {

	protected ConnectionManager connectionManager;
	private static AttendeesDao instance = null;

	protected AttendeesDao() {
		connectionManager = new ConnectionManager();
	}

	public static AttendeesDao getInstance() {
		if (instance == null) {
			instance = new AttendeesDao();
		}
		return instance;
	}

	public Attendees create(Attendees attendee) throws SQLException {
		String insertAttendees = "INSERT INTO Attendees(Attending,UserFK,PartyFK) VALUES(?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertAttendees);
			insertStmt.setString(1, attendee.getAttending().name());
			insertStmt.setInt(2, attendee.getUserFK());
			insertStmt.setString(3, attendee.getPartyFK());
			insertStmt.executeUpdate();
			return attendee;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (insertStmt != null) {
				insertStmt.close();
			}
		}
	}

	public Attendees getAttendeesById(int attendeeId) throws SQLException {
		String selectAttendees = "SELECT * FROM Attendees WHERE AttendeeId=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectAttendees);
			selectStmt.setInt(1, attendeeId);
			results = selectStmt.executeQuery();
			if (results.next()) {
				Attending attending = Attending.valueOf(results.getString("Attending"));
				int userFK = results.getInt("UserFK");
				String partyFK = results.getString("PartyFK");
				return new Attendees(attending, userFK, partyFK);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (selectStmt != null) {
				selectStmt.close();
			}
			if (results != null) {
				results.close();
			}
		}
		return null;
	}

	public int getLastId() throws SQLException {
		String select = "SELECT * FROM Attendees;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(select);
			results = selectStmt.executeQuery();
			int id = 0;
			while (results.next()) {
				id = results.getInt("AttendeeId");
			}
			
			return id;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (selectStmt != null) {
				selectStmt.close();
			}
			if (results != null) {
				results.close();
			}
		}
	}

	public Attendees updateAttending(int id, Attendees attendees, Attending newAttending) throws SQLException {
		String updateAttendee = "UPDATE Attendees SET Attending=? WHERE AttendeeId=?;";
		Connection connection = null;
		PreparedStatement updateStmt = null;
		try {
			connection = connectionManager.getConnection();
			updateStmt = connection.prepareStatement(updateAttendee);
			updateStmt.setString(1, newAttending.name());
			updateStmt.setInt(2, id);
			updateStmt.executeUpdate();
			attendees.setAttending(newAttending);
			return attendees;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (updateStmt != null) {
				updateStmt.close();
			}
		}
	}
	
	public Attendees delete(int id) throws SQLException {
		String deleteAttendees = "DELETE FROM Attendees WHERE AttendeeId=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deleteAttendees);
			deleteStmt.setInt(1, id);
			deleteStmt.executeUpdate();
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}

}
