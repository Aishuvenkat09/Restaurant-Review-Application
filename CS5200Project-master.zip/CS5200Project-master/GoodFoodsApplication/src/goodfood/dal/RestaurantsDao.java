//Joseph Triolo
//11/7/2019
//DBMS
//GoodFood Project

package goodfood.dal;

import goodfood.model.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

public class RestaurantsDao {
	protected ConnectionManager connectionManager;
	private static RestaurantsDao instance = null;
	
	protected RestaurantsDao() {
		connectionManager = new ConnectionManager();
	}
	
	public static RestaurantsDao getInstance() {
		if(instance == null) {
			instance = new RestaurantsDao();
		}
		return instance;
	}
	
	public Restaurants create(Restaurants restaurant) throws SQLException {
		String insertRestaurant = "INSERT INTO Restaurants(RestaurantId,RestaurantName,Alias,Rating,Price,Phone,Address1,Address2,Address3,City,State,Country,Zip) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertRestaurant);
			insertStmt.setString(1, restaurant.getRestaurantId());
			insertStmt.setString(2, restaurant.getRestaurantName());
			insertStmt.setString(3, restaurant.getAlias());
			insertStmt.setFloat(4, restaurant.getRating());
			insertStmt.setString(5, restaurant.getPrice());
			insertStmt.setString(6, restaurant.getPhone());
			insertStmt.setString(7, restaurant.getAddress1());
			insertStmt.setString(8, restaurant.getAddress2());
			insertStmt.setString(9, restaurant.getAddress3());
			insertStmt.setString(10, restaurant.getCity());
			insertStmt.setString(11, restaurant.getState());
			insertStmt.setString(12, restaurant.getCountry());
			insertStmt.setString(13, restaurant.getZip());
			insertStmt.executeUpdate();
			return restaurant;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(insertStmt != null) {
				insertStmt.close();
			}
		}
	}
	
	public Restaurants getRestaurantById(String restaurantId) throws SQLException {
		String selectRestaurant = "SELECT RestaurantId,RestaurantName,Alias,Rating,Price,Phone,Address1,Address2,Address3,City,State,Country,Zip FROM Restaurants WHERE RestaurantId=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectRestaurant);
			selectStmt.setString(1, restaurantId);
			results = selectStmt.executeQuery();
			if(results.next()) {
				String resultRestaurantId = results.getString("RestaurantId");
				String restaurantName = results.getString("RestaurantName");
				String alias = results.getString("Alias");
				float rating = results.getFloat("Rating");
				String price = results.getString("Price");
				String phone = results.getString("Phone");
				String address1 = results.getString("Address1");
				String address2 = results.getString("Address2");
				String address3 = results.getString("Address3");
				String city = results.getString("City");
				String state = results.getString("State");
				String country = results.getString("Country");
				String zip = results.getString("Zip");
				Restaurants restaurant = new Restaurants(resultRestaurantId, restaurantName, alias, rating, price, phone,
						address1, address2, address3, city, state, country, zip);
				return restaurant;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null;
	}
	
	public List<Restaurants> getRestaurantsByZip(String zip) throws SQLException {
		List<Restaurants> restaurants = new ArrayList<Restaurants>();
		String selectRestaurants = "SELECT RestaurantId,RestaurantName,Alias,Rating,Price,Phone,Address1,Address2,Address3,City,State,Country,Zip FROM Restaurants WHERE Zip=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectRestaurants);
			selectStmt.setString(1, zip);
			results = selectStmt.executeQuery();
			while(results.next()) {
				String resultRestaurantId = results.getString("RestaurantId");
				String restaurantName = results.getString("RestaurantName");
				String alias = results.getString("Alias");
				float rating = results.getFloat("Rating");
				String price = results.getString("Price");
				String phone = results.getString("Phone");
				String address1 = results.getString("Address1");
				String address2 = results.getString("Address2");
				String address3 = results.getString("Address3");
				String city = results.getString("City");
				String state = results.getString("State");
				String country = results.getString("Country");
				String resultZip = results.getString("Zip");
				Restaurants restaurant = new Restaurants(resultRestaurantId, restaurantName, alias, rating, price, phone,
						address1, address2, address3, city, state, country, resultZip);
				restaurants.add(restaurant);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return restaurants;
	}
	
	public List<Restaurants> getRestaurantsByCredentials(String zip, String rating, String category) throws SQLException {
		boolean zipComplete = false;
		boolean ratingComplete = false;
		boolean categoryComplete = false;
		List<Restaurants> restaurants = new ArrayList<Restaurants>();
		String selectRestaurants = "SELECT * FROM CategoryLinks RIGHT OUTER JOIN Restaurants ON CategoryLinks.RestaurantFK=Restaurants.RestaurantId " + 
				"WHERE ";
		if(!zip.trim().isEmpty() && zip != null) {
			selectRestaurants += "Zip=? ";
			zipComplete = true;
		}
		if(!rating.trim().isEmpty() && rating != null) {
			if(zipComplete) {
				selectRestaurants += "AND ";
			}
			selectRestaurants += "Rating>=? ";
			ratingComplete = true;
		}
		if(!category.trim().isEmpty() && category != null) {
			if(zipComplete || ratingComplete) {
				selectRestaurants += "AND ";
			}
			selectRestaurants += "CategoryFK=? ";
			categoryComplete = true;
		}
		selectRestaurants += "GROUP BY RestaurantId ORDER BY Rating DESC LIMIT 100;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectRestaurants);
			if(zipComplete) {
				selectStmt.setString(1, zip);
			}
			if(zipComplete && ratingComplete) {
				selectStmt.setFloat(2, Float.parseFloat(rating));
			}
			else if(ratingComplete) {
				selectStmt.setFloat(1, Float.parseFloat(rating));
			}
			if(zipComplete && ratingComplete && categoryComplete) {
				selectStmt.setString(3, category);
			}
			else if((zipComplete || ratingComplete) && categoryComplete) {
				selectStmt.setString(2, category);
			}
			else if(categoryComplete) {
				selectStmt.setString(1, category);
			}
			results = selectStmt.executeQuery();
			while(results.next()) {
				String resultRestaurantId = results.getString("RestaurantId");
				String restaurantName = results.getString("RestaurantName");
				String alias = results.getString("Alias");
				float resultRating = results.getFloat("Rating");
				String price = results.getString("Price");
				String phone = results.getString("Phone");
				String address1 = results.getString("Address1");
				String address2 = results.getString("Address2");
				String address3 = results.getString("Address3");
				String city = results.getString("City");
				String state = results.getString("State");
				String country = results.getString("Country");
				String resultZip = results.getString("Zip");
				Restaurants restaurant = new Restaurants(resultRestaurantId, restaurantName, alias, resultRating, price, phone,
						address1, address2, address3, city, state, country, resultZip);
				restaurants.add(restaurant);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return restaurants;
	}
	
	public Restaurants updateRestaurant(Restaurants restaurant, Restaurants newRestaurant) throws SQLException {
		String updateRestaurant = "UPDATE Restaurants SET RestaurantName=?,Alias=?,Rating=?,Price=?,Phone=?,"
				+ "Address1=?,Address2=?,Address3=?,City=?,State=?,Country=?,Zip=? WHERE RestaurantId=?;";
		Connection connection = null;
		PreparedStatement updateStmt = null;
		try {
			connection = connectionManager.getConnection();
			updateStmt = connection.prepareStatement(updateRestaurant);
			updateStmt.setString(1, newRestaurant.getRestaurantName());
			updateStmt.setString(2, newRestaurant.getAlias());
			updateStmt.setFloat(3, newRestaurant.getRating());
			updateStmt.setString(4, newRestaurant.getPrice());
			updateStmt.setString(5, newRestaurant.getPhone());
			updateStmt.setString(6, newRestaurant.getAddress1());
			updateStmt.setString(7, newRestaurant.getAddress2());
			updateStmt.setString(8, newRestaurant.getAddress3());
			updateStmt.setString(9, newRestaurant.getCity());
			updateStmt.setString(10, newRestaurant.getState());
			updateStmt.setString(11, newRestaurant.getCountry());
			updateStmt.setString(12, newRestaurant.getZip());
			updateStmt.setString(13, restaurant.getRestaurantId());
			updateStmt.executeUpdate();
			
			newRestaurant.setRestaurantId(restaurant.getRestaurantId());
			return newRestaurant;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(updateStmt != null) {
				updateStmt.close();
			}
		}
	}
	
	public Restaurants delete(Restaurants restaurant) throws SQLException {
		String deleteRestaurant = "DELETE FROM Restaurants WHERE RestaurantId=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deleteRestaurant);
			deleteStmt.setString(1, restaurant.getRestaurantId());
			deleteStmt.executeUpdate();
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}
}
