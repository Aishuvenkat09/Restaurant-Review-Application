package goodfood.dal;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import goodfood.model.Reservations;
import goodfood.model.Reservations;
import goodfood.model.Restaurants;
import goodfood.model.Users;

/**
 * @Date : Nov 9, 2019
 *
 * @Author: Divyavijay Sahay
 */

public class ReservationsDao {

	protected ConnectionManager connectionManager;
	private static ReservationsDao instance = null;

	protected ReservationsDao() {
		connectionManager = new ConnectionManager();
	}

	public static ReservationsDao getInstance() {
		if (instance == null) {
			instance = new ReservationsDao();
		}
		return instance;
	}

	public Reservations create(Reservations reservation) throws SQLException {
		String insertReservations = "INSERT INTO Reservations(Size,StartTime,EndTime,UserFK,RestaurantFK) VALUES(?,?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertReservations);
			insertStmt.setInt(1, reservation.getSize());
			insertStmt.setTimestamp(2, new Timestamp(reservation.getStartTime().getTime()));
			insertStmt.setTimestamp(3, new Timestamp(reservation.getStartTime().getTime()));
			insertStmt.setInt(4, reservation.getUserFK());
			insertStmt.setString(5, reservation.getRestaurantFK());
			insertStmt.executeUpdate();
			return reservation;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (insertStmt != null) {
				insertStmt.close();
			}
		}
	}

	public Reservations getReservationsById(int reservationId) throws SQLException {
		String selectReservations = "SELECT * FROM Reservations WHERE ReservationId=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectReservations);
			selectStmt.setInt(1, reservationId);
			results = selectStmt.executeQuery();
			if (results.next()) {
				int size = results.getInt("Size");
				Date start = new Date(results.getTimestamp("StartTime").getTime());
				Date end = new Date(results.getTimestamp("EndTime").getTime());
				int userFK = results.getInt("UserFK");
				String restaurantFK = results.getString("RestaurantFK");
				return new Reservations(size, start, end, userFK, restaurantFK);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (selectStmt != null) {
				selectStmt.close();
			}
			if (results != null) {
				results.close();
			}
		}
		return null;
	}

	public List<Reservations> getReservationsByRestaurantId(String restaurantId)throws SQLException {
		List<Reservations> reservations = new ArrayList<Reservations>();
		String selectReservations =
			"SELECT * " +
			"FROM Reservations " +
			"WHERE RestaurantFK=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectReservations);
			selectStmt.setString(1,restaurantId);
			results = selectStmt.executeQuery();
			
			while(results.next()) {
				int size = results.getInt("Size");
				Date start = new Date(results.getTimestamp("StartTime").getTime());
				Date end = new Date(results.getTimestamp("EndTime").getTime());
				int userFK = results.getInt("UserFK");
				String restaurantFK = results.getString("RestaurantFK");
				Reservations reservation = new Reservations(size, start, end, userFK, restaurantFK);
				reservations.add(reservation);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return reservations;
	}
	
	
	public int getLastId() throws SQLException {
		String select = "SELECT * FROM Reservations;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(select);
			results = selectStmt.executeQuery();
			int id = 0;
			while (results.next()) {
				id = results.getInt("ReservationId");
			}

			return id;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (selectStmt != null) {
				selectStmt.close();
			}
			if (results != null) {
				results.close();
			}
		}
	}

	public Reservations updateSize(int id, Reservations reservations, int newSize) throws SQLException {
		String updateReservation = "UPDATE Reservations SET Size=? WHERE ReservationId=?;";
		Connection connection = null;
		PreparedStatement updateStmt = null;
		try {
			connection = connectionManager.getConnection();
			updateStmt = connection.prepareStatement(updateReservation);
			updateStmt.setInt(1, newSize);
			updateStmt.setInt(2, id);
			updateStmt.executeUpdate();
			reservations.setSize(newSize);
			return reservations;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (updateStmt != null) {
				updateStmt.close();
			}
		}
	}
	
	public Reservations delete(int id) throws SQLException {
		String deleteReservations = "DELETE FROM Reservations WHERE ReservationId=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deleteReservations);
			deleteStmt.setInt(1, id);
			deleteStmt.executeUpdate();
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}

}
