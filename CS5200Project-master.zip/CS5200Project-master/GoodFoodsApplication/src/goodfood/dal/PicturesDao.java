package goodfood.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import goodfood.model.Pictures;

/**
 * @Date : Nov 9, 2019
 *
 * @Author: Divyavijay Sahay  
 */

public class PicturesDao {

	protected ConnectionManager connectionManager;
	private static PicturesDao instance = null;

	protected PicturesDao() {
		connectionManager = new ConnectionManager();
	}

	public static PicturesDao getInstance() {
		if (instance == null) {
			instance = new PicturesDao();
		}
		return instance;
	}

	public Pictures create(Pictures picture) throws SQLException {
		String insertPictures = "INSERT INTO Pictures(URL,RestaurantFK) VALUES(?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertPictures);
			insertStmt.setString(1, picture.getUrl());
			insertStmt.setString(2, picture.getRestaurantFK());
			insertStmt.executeUpdate();
			return picture;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (insertStmt != null) {
				insertStmt.close();
			}
		}
	}

	public Pictures getPicturesById(String url) throws SQLException {
		String selectPictures = "SELECT * FROM Pictures WHERE URL=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectPictures);
			selectStmt.setString(1, url);
			results = selectStmt.executeQuery();
			if (results.next()) {
				String URL = results.getString("URL");
				String restaurant = results.getString("RestaurantFK");
				return new Pictures(URL, restaurant);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (selectStmt != null) {
				selectStmt.close();
			}
			if (results != null) {
				results.close();
			}
		}
		return null;
	}
	
	public List<Pictures> getPicturesByRestaurantId(String restaurantId) throws SQLException {
		List<Pictures> pictures = new ArrayList<Pictures>();
		String selectPictures = "SELECT * FROM Pictures WHERE RestaurantFK=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectPictures);
			selectStmt.setString(1, restaurantId);
			results = selectStmt.executeQuery();
			while (results.next()) {
				String url = results.getString("URL");
				String restaurantFK = results.getString("RestaurantFK");
				pictures.add(new Pictures(url, restaurantFK));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (selectStmt != null) {
				selectStmt.close();
			}
			if (results != null) {
				results.close();
			}
		}
		return pictures;
	}

	public Pictures delete(Pictures pictures) throws SQLException {
		String deletePictures = "DELETE FROM Pictures WHERE URL=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deletePictures);
			deleteStmt.setString(1, pictures.getUrl());
			deleteStmt.executeUpdate();
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}
	
}
