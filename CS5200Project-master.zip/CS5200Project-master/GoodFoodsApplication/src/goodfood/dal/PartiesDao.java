package goodfood.dal;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import goodfood.model.Parties;

/**
 * @Date : Nov 9, 2019
 *
 * @Author: Divyavijay Sahay
 */

public class PartiesDao {

	protected ConnectionManager connectionManager;
	private static PartiesDao instance = null;

	protected PartiesDao() {
		connectionManager = new ConnectionManager();
	}

	public static PartiesDao getInstance() {
		if (instance == null) {
			instance = new PartiesDao();
		}
		return instance;
	}

	public Parties create(Parties party) throws SQLException {
		String insertParty = "INSERT INTO Parties(PartyId,PartyName,About,Cost, CostMax, IsCanceled, StartTime, EndTime,"
				+ "Address1, Address2, Address3, City, State, Country, Zip) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertParty);
			insertStmt.setString(1, party.getPartyId());
			insertStmt.setString(2, party.getPartyName());
			insertStmt.setString(3, party.getAbout());
			insertStmt.setFloat(4, party.getCost());
			insertStmt.setFloat(5, party.getCostMax());
			insertStmt.setInt(6, party.getIsCanceled());
			insertStmt.setTimestamp(7, new Timestamp(party.getStartTime().getTime()));
			insertStmt.setTimestamp(8, new Timestamp(party.getEndTime().getTime()));
			insertStmt.setString(9, party.getAddress1());
			insertStmt.setString(10, party.getAddress2());
			insertStmt.setString(11, party.getAddress3());
			insertStmt.setString(12, party.getCity());
			insertStmt.setString(13, party.getState());
			insertStmt.setString(14, party.getCountry());
			insertStmt.setString(15, party.getZip());

			insertStmt.executeUpdate();
			return party;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (insertStmt != null) {
				insertStmt.close();
			}
		}
	}

	public Parties getPartyById(String partyId) throws SQLException {
		String selectParty = "SELECT * FROM Parties WHERE PartyId=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectParty);
			selectStmt.setString(1, partyId);
			results = selectStmt.executeQuery();
			if (results.next()) {
				String id = results.getString("PartyId");
				String name = results.getString("PartyName");
				String about = results.getString("About");
				float cost = results.getFloat("Cost");
				float costMax = results.getFloat("CostMax");
				int isCanceled = results.getInt("IsCanceled");
				Date start = new Date(results.getTimestamp("StartTime").getTime());
				Date end = new Date(results.getTimestamp("EndTime").getTime());
				String address1 = results.getString("Address1");
				String address2 = results.getString("Address2");
				String address3 = results.getString("Address3");
				String city = results.getString("City");
				String state = results.getString("State");
				String country = results.getString("Country");
				String zip = results.getString("Zip");

				return new Parties(id, name, about, cost, costMax, isCanceled, start, end, address1, address2,
						address3, city, state, country, zip);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (selectStmt != null) {
				selectStmt.close();
			}
			if (results != null) {
				results.close();
			}
		}
		return null;
	}

	public Parties updateAbout(Parties parties, String newAbout) throws SQLException {
		String updatePartie = "UPDATE Parties SET About=? WHERE PartyId=?;";
		Connection connection = null;
		PreparedStatement updateStmt = null;
		try {
			connection = connectionManager.getConnection();
			updateStmt = connection.prepareStatement(updatePartie);
			updateStmt.setString(1, newAbout);
			updateStmt.setString(2, parties.getPartyId());
			updateStmt.executeUpdate();
			parties.setAbout(newAbout);
			return parties;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (updateStmt != null) {
				updateStmt.close();
			}
		}
	}
	
	public Parties delete(Parties party) throws SQLException {
		String deleteParty = "DELETE FROM Parties WHERE PartyId=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deleteParty);
			deleteStmt.setString(1, party.getPartyId());
			deleteStmt.executeUpdate();
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}

}
