//Aishwarya Vantipuli


package goodfood.dal;

import goodfood.model.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;

import java.util.List;


public class ReviewsDao {
	protected ConnectionManager connectionManager;

	private static ReviewsDao instance = null;
	protected ReviewsDao() {
		connectionManager = new ConnectionManager();
	}
	public static ReviewsDao getInstance() {
		if(instance == null) {
			instance = new ReviewsDao();
		}
		return instance;
	}

	public Reviews create(Reviews review) throws SQLException {
		String insertReviews =
			"INSERT INTO Reviews(ReviewId, Content,  Rating, UserFK, RestaurantFK) " +
			"VALUES(?,?,?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		ResultSet resultKey = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertReviews);
			
			insertStmt.setString(1, review.getReviewId());
			insertStmt.setString(2, review.getContent());
			insertStmt.setInt(3, review.getRating());
			insertStmt.setInt(4, review.getUser().getUserId());
			insertStmt.setString(5, review.getRestaurant().getRestaurantId());
			insertStmt.executeUpdate();
			
			return review;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(insertStmt != null) {
				insertStmt.close();
			}
			if(resultKey != null) {
				resultKey.close();
			}
		}
	}


	public Reviews getReviewById(String reviewId) throws SQLException {
		String selectReview =
			"SELECT * " +
			"FROM Reviews " +
			"WHERE ReviewId=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectReview);
			selectStmt.setString(1, reviewId);
			results = selectStmt.executeQuery();
			UsersDao usersDao = UsersDao.getInstance();
			RestaurantsDao restaurantsDao = RestaurantsDao.getInstance();
			if(results.next()) {
				String resultReviewId = results.getString("ReviewId");
				
				String content = results.getString("Content");
				int rating =  results.getInt("Rating");
				
				int userId = results.getInt("UserFK");
				String restaurantId = results.getString("RestaurantFK");
				
				Users user = usersDao.getUserByUserId(userId);
				Restaurants restaurant = restaurantsDao.getRestaurantById(restaurantId);
				Reviews review = new Reviews(resultReviewId, content,rating,
					 user, restaurant);
				return review;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null;
	}

	
	public List<Reviews> getReviewsByUserId(int userId)throws SQLException {
		List<Reviews> reviews = new ArrayList<Reviews>();
		String selectReviews =
			"SELECT  *" +
			"FROM Reviews " +
			"WHERE UserFK=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectReviews);
			selectStmt.setInt(1,userId);
			results = selectStmt.executeQuery();
			UsersDao usersDao = UsersDao.getInstance();
			RestaurantsDao restaurantsDao = RestaurantsDao.getInstance();
			while(results.next()) {
				String reviewId = results.getString("ReviewId");
				String content = results.getString("Content");
				int rating = results.getInt("Rating");
				int resultUserId = results.getInt("UserFK");
				String restaurantId = results.getString("RestaurantFK");
				
				Users user = usersDao.getUserByUserId(resultUserId);
				Restaurants restaurant = restaurantsDao.getRestaurantById(restaurantId);
				Reviews review = new Reviews(reviewId, content,rating,
						user, restaurant);
				
				reviews.add(review);

		
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return reviews;
	}
	
	public List<Reviews> getReviewsByRestaurantId(String restaurantId)throws SQLException {
		List<Reviews> reviews = new ArrayList<Reviews>();
		String selectReviews =
			"SELECT * " +
			"FROM Reviews " +
			"WHERE RestaurantFK=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectReviews);
			selectStmt.setString(1,restaurantId);
			results = selectStmt.executeQuery();
			UsersDao usersDao = UsersDao.getInstance();
			RestaurantsDao restaurantsDao = RestaurantsDao.getInstance();
			while(results.next()) {
				String reviewId = results.getString("ReviewId");
		
				String content = results.getString("Content");
				int rating  =  results.getInt("Rating");
				int userId = results.getInt("UserFK");
				String resultRestaurantId = results.getString("RestaurantFK");
				
				Users user = usersDao.getUserByUserId(userId);
				Restaurants restaurant = restaurantsDao.getRestaurantById(resultRestaurantId);
				Reviews review = new Reviews(reviewId,content,rating,user, restaurant);
				reviews.add(review);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return reviews;
	}
	
	public Reviews updateReview(Reviews review, Reviews newReview) throws SQLException {
		String updateReview = "UPDATE Reviews SET Content=?,Rating=?,UserFK=? WHERE ReviewId=?;";
		Connection connection = null;
		PreparedStatement updateStmt = null;
		try {
			connection = connectionManager.getConnection();
			updateStmt = connection.prepareStatement(updateReview);
			updateStmt.setString(1, newReview.getContent());
			updateStmt.setInt(2, newReview.getRating());
			updateStmt.setInt(3, newReview.getUser().getUserId());
			updateStmt.setString(4, review.getReviewId());
			updateStmt.executeUpdate();
			
			newReview.setReviewId(review.getReviewId());
			return newReview;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(updateStmt != null) {
				updateStmt.close();
			}
		}
	}
	
	
	public Reviews delete(Reviews review)
 throws SQLException {
		String deleteReview = "DELETE FROM Reviews WHERE ReviewId=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deleteReview);
			deleteStmt.setString(1, review.getReviewId());
			deleteStmt.executeUpdate();

			
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}

	
	
	
}
