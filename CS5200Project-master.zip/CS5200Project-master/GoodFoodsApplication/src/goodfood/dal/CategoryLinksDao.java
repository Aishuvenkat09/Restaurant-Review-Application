//Joseph Triolo
//11/7/2019
//DBMS
//GoodFood Project

package goodfood.dal;

import goodfood.model.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoryLinksDao {
	protected ConnectionManager connectionManager;
	private static CategoryLinksDao instance = null;
	
	protected CategoryLinksDao() {
		connectionManager = new ConnectionManager();
	}
	
	public static CategoryLinksDao getInstance() {
		if(instance == null) {
			instance = new CategoryLinksDao();
		}
		return instance;
	}
	
	public CategoryLinks create(CategoryLinks categoryLink) throws SQLException {
		String insertCategoryLink = "INSERT INTO CategoryLinks(CategoryLinkId,CategoryFK,RestaurantFK) VALUES(?,?,?);";
		Connection connection = null;
		PreparedStatement insertStmt = null;
		try {
			connection = connectionManager.getConnection();
			insertStmt = connection.prepareStatement(insertCategoryLink);
			insertStmt.setInt(1, categoryLink.getCategoryLinkId());
			insertStmt.setString(2, categoryLink.getCategoryFK());
			insertStmt.setString(3, categoryLink.getRestaurantFK());
			insertStmt.executeUpdate();
			return categoryLink;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(insertStmt != null) {
				insertStmt.close();
			}
		}
	}
	
	public CategoryLinks getCategoryLinkById(int categoryLinkId) throws SQLException {
		String selectCategoryLink = "SELECT CategoryLinkId,CategoryFK,RestaurantFK FROM CategoryLinks WHERE CategoryLinkId=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectCategoryLink);
			selectStmt.setInt(1, categoryLinkId);
			results = selectStmt.executeQuery();
			if(results.next()) {
				int resultCategoryLinkId = results.getInt("CategoryLinkId");
				String categoryFK = results.getString("CategoryFK");
				String restaurantFK = results.getString("RestaurantFK");
				CategoryLinks categoryLink = new CategoryLinks(resultCategoryLinkId, categoryFK, restaurantFK);
				return categoryLink;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return null;
	}
	
	public List<CategoryLinks> getCategoryLinksByRestaurantId(String restaurantId) throws SQLException {
		List<CategoryLinks> categoryLinks = new ArrayList<CategoryLinks>();
		String selectCategoryLinks = "SELECT CategoryLinkId,CategoryFK,RestaurantFK FROM CategoryLinks WHERE RestaurantFK=?;";
		Connection connection = null;
		PreparedStatement selectStmt = null;
		ResultSet results = null;
		try {
			connection = connectionManager.getConnection();
			selectStmt = connection.prepareStatement(selectCategoryLinks);
			selectStmt.setString(1, restaurantId);
			results = selectStmt.executeQuery();
			while(results.next()) {
				int resultCategoryLinkId = results.getInt("CategoryLinkId");
				String categoryFK = results.getString("CategoryFK");
				String restaurantFK = results.getString("RestaurantFK");
				CategoryLinks categoryLink = new CategoryLinks(resultCategoryLinkId, categoryFK, restaurantFK);
				categoryLinks.add(categoryLink);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(selectStmt != null) {
				selectStmt.close();
			}
			if(results != null) {
				results.close();
			}
		}
		return categoryLinks;
	}
	
	public CategoryLinks delete(CategoryLinks categoryLink) throws SQLException {
		String deleteCategoryLink = "DELETE FROM CategoryLinks WHERE CategoryLinkId=?;";
		Connection connection = null;
		PreparedStatement deleteStmt = null;
		try {
			connection = connectionManager.getConnection();
			deleteStmt = connection.prepareStatement(deleteCategoryLink);
			deleteStmt.setInt(1, categoryLink.getCategoryLinkId());
			deleteStmt.executeUpdate();
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			if(connection != null) {
				connection.close();
			}
			if(deleteStmt != null) {
				deleteStmt.close();
			}
		}
	}
}
