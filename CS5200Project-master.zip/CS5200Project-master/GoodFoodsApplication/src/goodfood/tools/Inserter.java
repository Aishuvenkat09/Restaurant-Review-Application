package goodfood.tools;

import goodfood.dal.*;
import goodfood.model.*;
import goodfood.model.Attendees.Attending;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

/**
 * main() runner, used for the app demo.
 * 
 * Instructions: 1. Create a new MySQL schema and then run the CREATE TABLE statements from lecture:
 * http://goo.gl/86a11H. 2. Update ConnectionManager with the correct user, password, and schema.
 */
public class Inserter {

	public static void main(String[] args) throws SQLException {
		/**
		 * AdministratorsDao administratorsDao = AdministratorsDao.getInstance(); BlogUsersDao blogUsersDao =
		 * BlogUsersDao.getInstance(); BlogPostsDao blogPostsDao = BlogPostsDao.getInstance(); BlogCommentsDao
		 * blogCommentsDao = BlogCommentsDao.getInstance(); ResharesDao resharesDao = ResharesDao.getInstance();
		 * 
		 * 
		 **/

		// Users
		UsersDao usersDao = UsersDao.getInstance();
		Users user = new Users("bruceb8", "1233", "bruce", "b", "abc@gmail.com", "127373");
		user = usersDao.create(user);
		Users u1 = usersDao.getUserByUserId(user.getUserId());
		System.out.format("Reading person: u:%s f:%s l:%s \n", u1.getUserName(), u1.getFirstName(), u1.getLastName());

		RestaurantsDao restaurantsDao = RestaurantsDao.getInstance();

		// Restaurant
		Restaurants restaurant = new Restaurants("r9", "R1", "r_1", 5.0f, "$$", "1234567890", "a1", "a2", "a3", "c",
				"s", "c", "01234");
		restaurantsDao.create(restaurant);
		Restaurants r1 = restaurantsDao.getRestaurantById(restaurant.getRestaurantId());
		System.out.format("Reading restaurant: rid:%s rn:%s rating:%f \n", r1.getRestaurantId(), r1.getRestaurantName(),
				r1.getRating());

		r1 = restaurantsDao.getRestaurantById(restaurant.getRestaurantId());
		System.out.format("Reading restaurant: %s \n", r1);

		// Reviews
		ReviewsDao reviewsDao = ReviewsDao.getInstance();

		List<Reviews> reviews2 = reviewsDao.getReviewsByUserId(user.getUserId());
		for (Reviews rev : reviews2) {
			System.out.println(rev.getContent());
		}

		List<Reviews> reviews3 = reviewsDao.getReviewsByRestaurantId(restaurant.getRestaurantId());
		for (Reviews rev2 : reviews3) {
			System.out.println(rev2.getContent());
		}

		// Recommendations
		RecommendationsDao recommendationsDao = RecommendationsDao.getInstance();

		Recommendations recommendation = new Recommendations(user, restaurant);
		recommendationsDao.create(recommendation);

		Recommendations r111 = recommendationsDao.getRecommendationById(recommendation.getRecommendationId());
		System.out.format("Reading recommendation: n:%s u:%s \n", r111.getRestaurant().getRestaurantName(),
				r111.getUser().getUserName());

		List<Recommendations> recList1 = recommendationsDao.getRecommendationsByUserId(user.getUserId());
		for (Recommendations r : recList1) {
			System.out.format("Looping recommendation: id:%s n:%s\n", r.getRecommendationId(),
					r.getRestaurant().getRestaurantName());
		}
		List<Recommendations> recList11 = recommendationsDao
				.getRecommendationsByRestaurantId(restaurant.getRestaurantId());
		for (Recommendations rec2 : recList11) {
			System.out.println(rec2.getRestaurant().getRestaurantName());
		}

		// Parties
		PartiesDao partiesDao = PartiesDao.getInstance();
		Parties parties = new Parties("pdn7", "DiscoNight", "disco", 12.0f, 20.0f, 0,
				new Date(System.currentTimeMillis()), new Date(System.currentTimeMillis() + 1000), "some street",
				"some ave", "street", "Boston", "MA", "USA", "02115");
		parties = partiesDao.create(parties);

		Parties p1 = partiesDao.getPartyById(parties.getPartyId());
		System.out.format("Party Details : id:%s \tname: %s \tabout: %s \tstart: %s \tend: %s \tcost: %s\n",
				p1.getPartyId(), p1.getPartyName(), p1.getAbout(), p1.getStartTime(), p1.getEndTime(), p1.getCost());
		
		p1 = partiesDao.updateAbout(p1, "udpated about");
		System.out.format("Updated Party Details : id:%s \tname: %s \tabout: %s \tstart: %s \tend: %s \tcost: %s\n",
				p1.getPartyId(), p1.getPartyName(), p1.getAbout(), p1.getStartTime(), p1.getEndTime(), p1.getCost());

		
		// Attendees
		AttendeesDao attendeesDao = AttendeesDao.getInstance();
		Attendees attendees = new Attendees(Attending.YES, user.getUserId(), parties.getPartyId());
		attendees = attendeesDao.create(attendees);
		int lastEnteredAttendeeId = attendeesDao.getLastId();
		attendees = attendeesDao.getAttendeesById(lastEnteredAttendeeId);
		System.out.println(lastEnteredAttendeeId);
		System.out.format("Attendees details: id:%s \tuser: %s, \tparty: %s \tattending: %s\n", lastEnteredAttendeeId,
				attendees.getUserFK(), attendees.getPartyFK(), attendees.getAttending());

		attendees = attendeesDao.updateAttending(lastEnteredAttendeeId, attendees, Attending.MAYBE);
		System.out.format("Updated Attendees details: id:%s \tuser: %s, \tparty: %s \tattending: %s\n",
				lastEnteredAttendeeId, attendees.getUserFK(), attendees.getPartyFK(), attendees.getAttending());

		// Pictures
		PicturesDao picturesDao = PicturesDao.getInstance();
		Pictures pictures = new Pictures("www.some_food_picture_url.zom", restaurant.getRestaurantId());
		pictures = picturesDao.create(pictures);
		pictures = picturesDao.getPicturesById(pictures.getUrl());
		System.out.format("Picture details: url: %s \trestaurant: %s\n", pictures.getUrl(), pictures.getRestaurantFK());

		// Reservations
		ReservationsDao reservationsDao = ReservationsDao.getInstance();
		Reservations reservations = new Reservations(10, new Date(System.currentTimeMillis()),
				new Date(System.currentTimeMillis() + 1000), user.getUserId(), restaurant.getRestaurantId());
		reservations = reservationsDao.create(reservations);
		int lastEnteredReservationId = reservationsDao.getLastId();
		reservations = reservationsDao.getReservationsById(lastEnteredReservationId);
		System.out.format("Reservation deatils: size: %s \t start: %s \t end %s \t user: %s \t restaurant: %s\n",
				reservations.getSize(), reservations.getStartTime(), reservations.getEndTime(),
				reservations.getUserFK(), reservations.getRestaurantFK());
		reservations = reservationsDao.updateSize(lastEnteredReservationId, reservations, 20);
		System.out.format("Updated Reservation deatils: size: %s \t start: %s \t end %s \t user: %s \t restaurant: %s\n",
				reservations.getSize(), reservations.getStartTime(), reservations.getEndTime(),
				reservations.getUserFK(), reservations.getRestaurantFK());

		
		
		// Delete Operations
		restaurantsDao.delete(r1);
		usersDao.delete(user);
		recommendationsDao.delete(recommendation);
		partiesDao.delete(p1);
		attendeesDao.delete(lastEnteredAttendeeId);
		picturesDao.delete(pictures);
		reservationsDao.delete(lastEnteredReservationId);
	}
}
