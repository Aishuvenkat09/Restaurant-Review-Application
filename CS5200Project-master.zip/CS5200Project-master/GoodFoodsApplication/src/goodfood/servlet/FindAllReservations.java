package goodfood.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goodfood.dal.ReservationsDao;
import goodfood.model.Reservations;

/**
 * @Date : Nov 25, 2019
 *
 * @Author: Divyavijay Sahay  
 */

@WebServlet("/findallreservations")
public class FindAllReservations extends HttpServlet {
	
	protected ReservationsDao reservationsDao;
	
	@Override
	public void init() throws ServletException {
		reservationsDao = ReservationsDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        Map<String, String> messages = new HashMap<>();
        req.setAttribute("messages", messages);

        List<Reservations> reservations = new ArrayList<>();
        
        String restaurantid = req.getParameter("restaurantid");
        if (restaurantid == null || restaurantid.trim().isEmpty()) {
            messages.put("success", "Please enter a valid restaurant id.");
        } else {
        	try {
        		reservations = reservationsDao.getReservationsByRestaurantId(restaurantid);
            } catch (SQLException e) {
    			e.printStackTrace();
    			throw new IOException(e);
            }
        	messages.put("title", "Displaying results for " + restaurantid);
        }
        req.setAttribute("reservations", reservations);
        
        req.getRequestDispatcher("/FindAllReservations.jsp").forward(req, resp);
	}

}
