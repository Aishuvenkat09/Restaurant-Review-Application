//Joseph Triolo
//12/7/2019
//DBMS
//GoodFood Project

package goodfood.servlet;

import goodfood.dal.*;
import goodfood.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/reviewupdate")
public class ReviewUpdate extends HttpServlet {
	protected ReviewsDao reviewsDao;
	protected UsersDao usersDao;
	
	@Override
	public void init() throws ServletException {
		reviewsDao = ReviewsDao.getInstance();
		usersDao = UsersDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        String reviewId = req.getParameter("reviewId");
        if (reviewId == null || reviewId.trim().isEmpty()) {
            messages.put("success", "Please enter a valid ReviewId.");
        } else {
        	try {
        		Reviews review = reviewsDao.getReviewById(reviewId);
        		if(review == null) {
        			messages.put("success", "ReviewId does not exist.");
        		}
        		req.setAttribute("review", review);
        	} catch (SQLException e) {
				e.printStackTrace();
				throw new IOException(e);
	        }
        }
        
        req.getRequestDispatcher("/ReviewUpdate.jsp").forward(req, resp);
	}
	
	@Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
    		throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        String reviewId = req.getParameter("reviewId");
        if (reviewId == null || reviewId.trim().isEmpty()) {
            messages.put("success", "Please enter a valid ReviewId.");
        } else {
        	try {
        		Reviews review = reviewsDao.getReviewById(reviewId);
        		if(review == null) {
        			messages.put("success", "ReviewId does not exist. No update to perform.");
        		} else {
        			String username = req.getParameter("username");
        			String content = req.getParameter("content");
        			int rating = Integer.parseInt(req.getParameter("rating"));
        			int userId = Integer.parseInt(req.getParameter("userId"));
        			Users user = usersDao.getUserByUserId(userId);
                	Reviews newReview = new Reviews(reviewId,content,rating,user,review.getRestaurant());
        			review = reviewsDao.updateReview(review, newReview);
    	        	messages.put("success", "Successfully updated " + reviewId);
        		}
        		req.setAttribute("review", review);
        	} catch (SQLException e) {
				e.printStackTrace();
				throw new IOException(e);
	        }
        }
        
        req.getRequestDispatcher("/ReviewUpdate.jsp").forward(req, resp);
    }
}
