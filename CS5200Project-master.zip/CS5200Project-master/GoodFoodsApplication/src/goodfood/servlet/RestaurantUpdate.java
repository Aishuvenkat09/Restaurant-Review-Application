//Joseph Triolo
//11/10/2019
//DBMS
//GoodFood Project

package goodfood.servlet;

import goodfood.dal.*;
import goodfood.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/restaurantupdate")
public class RestaurantUpdate extends HttpServlet {
	protected RestaurantsDao restaurantsDao;
	
	@Override
	public void init() throws ServletException {
		restaurantsDao = RestaurantsDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        String restaurantId = req.getParameter("restaurantId");
        if (restaurantId == null || restaurantId.trim().isEmpty()) {
            messages.put("success", "Please enter a valid RestaurantId.");
        } else {
        	try {
        		Restaurants restaurant = restaurantsDao.getRestaurantById(restaurantId);
        		if(restaurant == null) {
        			messages.put("success", "RestaurantId does not exist.");
        		}
        		req.setAttribute("restaurant", restaurant);
        	} catch (SQLException e) {
				e.printStackTrace();
				throw new IOException(e);
	        }
        }
        
        req.getRequestDispatcher("/RestaurantUpdate.jsp").forward(req, resp);
	}
	
	@Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
    		throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        String restaurantId = req.getParameter("restaurantId");
        if (restaurantId == null || restaurantId.trim().isEmpty()) {
            messages.put("success", "Please enter a valid RestaurantId.");
        } else {
        	try {
        		Restaurants restaurant = restaurantsDao.getRestaurantById(restaurantId);
        		if(restaurant == null) {
        			messages.put("success", "RestaurantId does not exist. No update to perform.");
        		} else {
        			String restaurantName = req.getParameter("restaurantName");
                	String alias = req.getParameter("alias");
                	String stringRating = req.getParameter("rating");
                	String price = req.getParameter("price");
                	String phone = req.getParameter("phone");
                	String address1 = req.getParameter("address1");
                	String address2 = req.getParameter("address2");
                	String address3 = req.getParameter("address3");
                	String city = req.getParameter("city");
                	String state = req.getParameter("state");
                	String country = req.getParameter("country");
                	String zip = req.getParameter("zip");
                	float rating;
                	try {
                		rating = Float.parseFloat(stringRating);
                	} catch (NumberFormatException e) {
                		e.printStackTrace();
        				throw new IOException(e);
                	}
        			Restaurants newRestaurant = new Restaurants(restaurantId, restaurantName,alias,rating,price,phone,address1,address2,address3,
        					city,state,country,zip);
        			restaurant = restaurantsDao.updateRestaurant(restaurant, newRestaurant);
    	        	messages.put("success", "Successfully updated " + restaurantId);
        		}
        		req.setAttribute("restaurant", restaurant);
        	} catch (SQLException e) {
				e.printStackTrace();
				throw new IOException(e);
	        }
        }
        
        req.getRequestDispatcher("/RestaurantUpdate.jsp").forward(req, resp);
    }
}
