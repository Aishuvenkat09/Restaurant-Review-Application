//Joseph Triolo
//12/6/2019
//DBMS
//GoodFood Project

package goodfood.servlet;

import goodfood.dal.*;
import goodfood.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/restaurantrecommendations")
public class RestaurantRecommendations extends HttpServlet {
	protected RecommendationsDao recommendationsDao;
	protected UsersDao usersDao;
	protected RestaurantsDao restaurantsDao;
	
	@Override
	public void init() throws ServletException {
		recommendationsDao = RecommendationsDao.getInstance();
		usersDao = UsersDao.getInstance();
		restaurantsDao = RestaurantsDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
		
        List<Recommendations> recommendations = new ArrayList<Recommendations>();
        Restaurants restaurant = null;
        
        String restaurantId = req.getParameter("restaurantId");
        
        try {
        	restaurant = restaurantsDao.getRestaurantById(restaurantId);
        	recommendations = recommendationsDao.getRecommendationsByRestaurantId(restaurantId);
        	messages.put("title", "Recommendations for " + restaurant.getRestaurantName());
        } catch (SQLException e) {
			e.printStackTrace();
			throw new IOException(e);
        }
        req.setAttribute("restaurant", restaurant);
        req.setAttribute("recommendations", recommendations);
        req.getRequestDispatcher("/RestaurantRecommendations.jsp").forward(req, resp);
	}
}
