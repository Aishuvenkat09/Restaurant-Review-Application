package goodfood.servlet;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goodfood.dal.ReservationsDao;
import goodfood.model.Reservations;

/**
 * @Date : Nov 10, 2019
 *
 * @Author: Divyavijay Sahay
 */
@WebServlet("/reservationcreate")
public class ReservationCreate extends HttpServlet {

	protected ReservationsDao reservationsDao;

	@Override
	public void init() throws ServletException {
		reservationsDao = ReservationsDao.getInstance();
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Map<String, String> messages = new HashMap<String, String>();
		req.setAttribute("messages", messages);
		req.getRequestDispatcher("/ReservationCreate.jsp").forward(req, resp);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Map<String, String> messages = new HashMap<String, String>();
		req.setAttribute("messages", messages);

		int size = Integer.parseInt(req.getParameter("size"));
		int userFK = Integer.parseInt(req.getParameter("userFK"));
		String restaurantFK = req.getParameter("restaurantFK");
		
		java.sql.Date sqlStartDate = new Date(System.currentTimeMillis());
		java.sql.Date sqlEndDate = new Date(System.currentTimeMillis() + 12000);

		Reservations reservations = new Reservations(size, sqlStartDate, sqlEndDate, userFK, restaurantFK);
		try {
			reservations = reservationsDao.create(reservations);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new IOException(e);
		}
		messages.put("success", "Successfully created");
		
		req.getRequestDispatcher("/ReservationCreate.jsp").forward(req, resp);
	}

}
