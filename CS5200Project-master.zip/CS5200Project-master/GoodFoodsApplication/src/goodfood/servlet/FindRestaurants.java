//Joseph Triolo
//11/8/2019
//DBMS
//GoodFood Project

package goodfood.servlet;

import goodfood.dal.*;
import goodfood.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/findrestaurants")
public class FindRestaurants extends HttpServlet {
	
	protected RestaurantsDao restaurantsDao;
	
	@Override
	public void init() throws ServletException {
		restaurantsDao = RestaurantsDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        List<Restaurants> restaurants = new ArrayList<Restaurants>();
        
        String zip = req.getParameter("zip");
        String rating = req.getParameter("rating");
        String category = req.getParameter("category");
        if ((zip == null || zip.trim().isEmpty()) && (rating == null || rating.trim().isEmpty()) && (category == null || category.trim().isEmpty())) {
            messages.put("success", "Please enter a valid credential.");
        } else {
        	try {
        		restaurants = restaurantsDao.getRestaurantsByCredentials(zip,rating,category);
            } catch (SQLException e) {
    			e.printStackTrace();
    			throw new IOException(e);
            }
        	messages.put("success", "Displaying results for:\n" + zip + "\n" + rating + "\n" + category);
        	messages.put("previousZip", zip);
        }
        req.setAttribute("restaurants", restaurants);
        
        req.getRequestDispatcher("/FindRestaurants.jsp").forward(req, resp);
	}
	
	@Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
    		throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        List<Restaurants> restaurants = new ArrayList<Restaurants>();
        
        String zip = req.getParameter("zip");
        String rating = req.getParameter("rating");
        String category = req.getParameter("category");
        if ((zip == null || zip.trim().isEmpty()) && (rating == null || rating.trim().isEmpty()) && (category == null || category.trim().isEmpty())) {
            messages.put("success", "Please enter a valid credential.");
        } else {
        	try {
        		restaurants = restaurantsDao.getRestaurantsByCredentials(zip,rating,category);
            } catch (SQLException e) {
    			e.printStackTrace();
    			throw new IOException(e);
            }
        	messages.put("success", "Displaying results for:\n" + zip + "\n" + rating + "\n" + category);
        }
        req.setAttribute("restaurants", restaurants);
        
        req.getRequestDispatcher("/FindRestaurants.jsp").forward(req, resp);
    }

}
