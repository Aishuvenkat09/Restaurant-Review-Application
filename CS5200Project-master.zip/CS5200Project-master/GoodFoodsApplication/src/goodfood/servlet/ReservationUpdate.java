package goodfood.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goodfood.dal.ReservationsDao;
import goodfood.model.Reservations;

/**
 * @Date : Nov 10, 2019
 *
 * @Author: Divyavijay Sahay  
 */

@WebServlet("/reservationupdate")
public class ReservationUpdate extends HttpServlet {
	protected ReservationsDao reservationsDao;
	
	@Override
	public void init() throws ServletException {
		reservationsDao = ReservationsDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        String reservationId = req.getParameter("reservationId");
        if (reservationId == null || reservationId.trim().isEmpty()) {
            messages.put("success", "Please enter a valid ReservationId.");
        } else {
        	try {
        		Reservations reservation = reservationsDao.getReservationsById(Integer.parseInt(reservationId));
        		if(reservation == null) {
        			messages.put("success", "ReservationId does not exist.");
        		}
        		req.setAttribute("reservation", reservation);
        	} catch (SQLException e) {
				e.printStackTrace();
				throw new IOException(e);
	        }
        }
        
        req.getRequestDispatcher("/ReservationUpdate.jsp").forward(req, resp);
	}
	
	@Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
    		throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        String reservationId = req.getParameter("reservationId");
        if (reservationId == null || reservationId.trim().isEmpty()) {
            messages.put("success", "Please enter a valid ReservationId.");
        } else {
        	try {
        		Reservations reservation = reservationsDao.getReservationsById(Integer.parseInt(reservationId));
        		if(reservation == null) {
        			messages.put("success", "ReservationId does not exist. No update to perform.");
        		} else {
        			int newSize = Integer.parseInt(req.getParameter("size"));
        			reservation = reservationsDao.updateSize(Integer.parseInt(reservationId), reservation, newSize);
    	        	messages.put("success", "Successfully updated " + reservationId);
        		}
        		req.setAttribute("reservation", reservation);
        	} catch (SQLException e) {
				e.printStackTrace();
				throw new IOException(e);
	        }
        }
        
        req.getRequestDispatcher("/ReservationUpdate.jsp").forward(req, resp);
    }
}

