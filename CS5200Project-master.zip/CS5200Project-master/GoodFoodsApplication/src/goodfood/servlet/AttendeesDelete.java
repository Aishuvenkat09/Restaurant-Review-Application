package goodfood.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goodfood.dal.AttendeesDao;

/**
 * @Date : Nov 24, 2019
 *
 * @Author: Divyavijay Sahay  
 */

@WebServlet("/attendeeDelete")
public class AttendeesDelete extends HttpServlet {
	protected AttendeesDao attendeesDao;
	
	@Override
	public void init() throws ServletException {
		attendeesDao = AttendeesDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
        req.getRequestDispatcher("/AttendeesDelete.jsp").forward(req, resp);
	}
	
	@Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
    		throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        String attendeeId = req.getParameter("attendeeId");
        if (attendeeId == null || attendeeId.trim().isEmpty()) {
            messages.put("success", "Invalid AttendeeId");
        } else {
	        try {
	        	attendeesDao.delete(Integer.parseInt(attendeeId));
	        	messages.put("success", "Successfully deleted " + attendeeId);
	        } catch (SQLException e) {
				e.printStackTrace();
				throw new IOException(e);
	        }
        }
        
        req.getRequestDispatcher("/AttendeesDelete.jsp").forward(req, resp);
    }
}
