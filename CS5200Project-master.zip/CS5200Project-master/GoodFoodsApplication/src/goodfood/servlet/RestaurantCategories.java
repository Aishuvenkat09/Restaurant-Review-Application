//Joseph Triolo
//11/10/2019
//DBMS
//GoodFood Project

package goodfood.servlet;

import goodfood.dal.*;
import goodfood.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/restaurantcategories")
public class RestaurantCategories extends HttpServlet {
	protected CategoriesDao categoriesDao;
	protected CategoryLinksDao categoryLinksDao;
	protected RestaurantsDao restaurantsDao;
	
	@Override
	public void init() throws ServletException {
		categoriesDao = CategoriesDao.getInstance();
		categoryLinksDao = CategoryLinksDao.getInstance();
		restaurantsDao = RestaurantsDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
		
        List<Categories> categories = new ArrayList<Categories>();
        List<CategoryLinks> categoryLinks = new ArrayList<CategoryLinks>();
        Restaurants restaurant = null;
        
        String restaurantId = req.getParameter("restaurantId");
        
        try {
        	restaurant = restaurantsDao.getRestaurantById(restaurantId);
        	categoryLinks = categoryLinksDao.getCategoryLinksByRestaurantId(restaurantId);
        	for(CategoryLinks cl: categoryLinks) {
        		categories.add(categoriesDao.getCategoryByTitle(cl.getCategoryFK()));
        	}
        	messages.put("title", "Categories for " + restaurant.getRestaurantName());
        } catch (SQLException e) {
			e.printStackTrace();
			throw new IOException(e);
        }
        
        req.setAttribute("categories", categories);
        req.getRequestDispatcher("/RestaurantCategories.jsp").forward(req, resp);
	}
}
