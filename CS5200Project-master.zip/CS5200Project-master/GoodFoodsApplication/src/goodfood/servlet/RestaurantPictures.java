//Joseph Triolo
//11/21/2019
//DBMS
//GoodFood Project

package goodfood.servlet;

import goodfood.dal.*;
import goodfood.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/restaurantpictures")
public class RestaurantPictures extends HttpServlet {
	protected PicturesDao picturesDao;
	protected RestaurantsDao restaurantsDao;
	
	@Override
	public void init() throws ServletException {
		picturesDao = PicturesDao.getInstance();
		restaurantsDao = RestaurantsDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
		
        List<Pictures> pictures = new ArrayList<Pictures>();
        Restaurants restaurant = null;
        
        String restaurantId = req.getParameter("restaurantId");
        
        try {
        	pictures = picturesDao.getPicturesByRestaurantId(restaurantId);
        	restaurant = restaurantsDao.getRestaurantById(restaurantId);
        	messages.put("title", "Pictures for " + restaurant.getRestaurantName());
        } catch (SQLException e) {
			e.printStackTrace();
			throw new IOException(e);
        }
        
        req.setAttribute("pictures", pictures);
        req.getRequestDispatcher("/RestaurantPictures.jsp").forward(req, resp);
	}
}
