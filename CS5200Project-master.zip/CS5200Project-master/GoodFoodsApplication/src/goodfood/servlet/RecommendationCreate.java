
//Aishwarya Vantipuli


package goodfood.servlet;

import goodfood.dal.*;
import goodfood.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/recommendationcreate")
public class RecommendationCreate extends HttpServlet {
	
	protected RecommendationsDao recommendationsDao;
	
	@Override
	public void init() throws ServletException {
		recommendationsDao = RecommendationsDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// Map for storing messages.
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
        //Just render the JSP.   
        req.getRequestDispatcher("/RecommendationCreate.jsp").forward(req, resp);
	}
	
	@Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
    		throws ServletException, IOException {
        // Map for storing messages.
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

       
       
        	
        	
        	int userFK = Integer.parseInt(req.getParameter("userFK"));
        	String restaurantFK = req.getParameter("restaurantFK");
        	
        	{
        	Users user = new Users(userFK);
        	Restaurants restaurant = new Restaurants(restaurantFK);
        	try {
	        	
	        	Recommendations recommendation = new Recommendations( user, restaurant);
	        	recommendation = recommendationsDao.create(recommendation);
	        	messages.put("success", "Successfully created " );
	        } catch (SQLException e) {
				e.printStackTrace();
				throw new IOException(e);
	        }
	}
   

		req.getRequestDispatcher("/RecommendationCreate.jsp").forward(req, resp);
}
}
