package goodfood.servlet;

import goodfood.dal.*;
import goodfood.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/recommendationdelete")
public class RecommendationDelete extends HttpServlet {
	
	protected RecommendationsDao recommendationsDao;
	
	@Override
	public void init() throws ServletException {
		recommendationsDao = RecommendationsDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// Map for storing messages.
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
      
        messages.put("title", "Delete Recommendation");        
        req.getRequestDispatcher("/RecommendationDelete.jsp").forward(req, resp);
	}
	
	@Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
    		throws ServletException, IOException {
        // Map for storing messages.
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        // Retrieve and validate name.
        String recommendationId = req.getParameter("recommendationId");
        if (recommendationId == null || recommendationId.trim().isEmpty()) {
            messages.put("title", "Invalid RecommendationId");
         
        } else {
        	Recommendations recommendation = new Recommendations(Integer.parseInt(recommendationId));
	        try {
	        	recommendationsDao.delete(recommendation);
	        	messages.put("title", "Successfully deleted " + recommendationId);
	        	messages.put("disableSubmit", "true");
	        } catch (SQLException e) {
				e.printStackTrace();
				throw new IOException(e);
	        }
        }
        
        req.getRequestDispatcher("/RecommendationDelete.jsp").forward(req, resp);
    }
}
