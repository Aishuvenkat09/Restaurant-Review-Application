//Joseph Triolo
//12/6/2019
//DBMS
//GoodFood Project

package goodfood.servlet;

import goodfood.dal.*;
import goodfood.model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/restaurantreviews")
public class RestaurantReviews extends HttpServlet {
	protected ReviewsDao reviewsDao;
	protected UsersDao usersDao;
	protected RestaurantsDao restaurantsDao;
	
	@Override
	public void init() throws ServletException {
		reviewsDao = ReviewsDao.getInstance();
		usersDao = UsersDao.getInstance();
		restaurantsDao = RestaurantsDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
		
        List<Reviews> reviews = new ArrayList<Reviews>();
        Restaurants restaurant = null;
        
        String restaurantId = req.getParameter("restaurantId");
        
        try {
        	restaurant = restaurantsDao.getRestaurantById(restaurantId);
        	reviews = reviewsDao.getReviewsByRestaurantId(restaurantId);
        	messages.put("title", "Reviews for " + restaurant.getRestaurantName());
        } catch (SQLException e) {
			e.printStackTrace();
			throw new IOException(e);
        }
        req.setAttribute("restaurant", restaurant);
        req.setAttribute("reviews", reviews);
        req.getRequestDispatcher("/RestaurantReviews.jsp").forward(req, resp);
	}
}
