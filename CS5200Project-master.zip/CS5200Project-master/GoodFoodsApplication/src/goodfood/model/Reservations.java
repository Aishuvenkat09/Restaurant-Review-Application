package goodfood.model;

import java.sql.Date;

/**
 * @Date : Nov 9, 2019
 *
 * @Author: Divyavijay Sahay
 */

public class Reservations {

	private int size;
	private Date startTime;
	private Date endTime;
	private int userFK;
	private String restaurantFK;

	public Reservations(int size, Date startTime, Date endTime, int userFK, String restaurantFK) {
		super();
		this.size = size;
		this.startTime = startTime;
		this.endTime = endTime;
		this.userFK = userFK;
		this.restaurantFK = restaurantFK;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public int getUserFK() {
		return userFK;
	}

	public void setUserFK(int userFK) {
		this.userFK = userFK;
	}

	public String getRestaurantFK() {
		return restaurantFK;
	}

	public void setRestaurantFK(String restaurantFK) {
		this.restaurantFK = restaurantFK;
	}

}
