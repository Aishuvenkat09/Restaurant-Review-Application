package goodfood.model;

/**
 * @Date : Nov 9, 2019
 *
 * @Author: Divyavijay Sahay
 */

public class Pictures {

	private String url;
	private String restaurantFK;

	public Pictures(String url, String restaurantFK) {
		super();
		this.url = url;
		this.restaurantFK = restaurantFK;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getRestaurantFK() {
		return restaurantFK;
	}

	public void setRestaurantFK(String restaurantFK) {
		this.restaurantFK = restaurantFK;
	}

}
