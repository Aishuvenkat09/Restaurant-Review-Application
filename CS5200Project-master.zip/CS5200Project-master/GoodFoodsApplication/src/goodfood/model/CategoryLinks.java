//Joseph Triolo
//11/6/2019
//DBMS
//GoodFood Project

package goodfood.model;

public class CategoryLinks {
	protected int categoryLinkId;
	protected String categoryFK;
	protected String restaurantFK;
	
	public CategoryLinks(int categoryLinkId, String categoryFK, String restaurantFK) {
		this.categoryLinkId = categoryLinkId;
		this.categoryFK = categoryFK;
		this.restaurantFK = restaurantFK;
	}
	
	public CategoryLinks(int categoryLinkId) {
		this.categoryLinkId = categoryLinkId;
	}
	
	public int getCategoryLinkId() {
		return categoryLinkId;
	}
	public void setCategoryLinkId(int categoryLinkId) {
		this.categoryLinkId = categoryLinkId;
	}
	public String getCategoryFK() {
		return categoryFK;
	}
	public void setCategoryFK(String categoryFK) {
		this.categoryFK = categoryFK;
	}
	public String getRestaurantFK() {
		return restaurantFK;
	}
	public void setRestaurantFK(String restaurantFK) {
		this.restaurantFK = restaurantFK;
	}

}
