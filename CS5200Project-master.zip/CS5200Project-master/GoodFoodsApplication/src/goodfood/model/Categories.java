//Joseph Triolo
//11/6/2019
//DBMS
//GoodFood Project

package goodfood.model;

public class Categories {
	protected String title;
	protected String alias;
	
	public Categories(String title, String alias) {
		this.title = title;
		this.alias = alias;
	}
	
	public Categories(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}

}
