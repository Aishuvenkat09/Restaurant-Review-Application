package goodfood.model;

import java.sql.Date;

/**
 * @Date : Nov 9, 2019
 *
 * @Author: Divyavijay Sahay
 */

public class Parties {

	private String partyId;
	private String partyName;
	private String about;
	private float cost;
	private float costMax;
	private int isCanceled;
	private Date startTime;
	private Date endTime;
	private String address1;
	private String address2;
	private String address3;
	private String city;
	private String state;
	private String country;
	private String zip;

	public Parties(String partyId, String partyName, String about, float cost, float costMax, int isCanceled,
			Date startTime, Date endTime, String address1, String address2, String address3, String city, String state,
			String country, String zip) {
		super();
		this.partyId = partyId;
		this.partyName = partyName;
		this.about = about;
		this.cost = cost;
		this.costMax = costMax;
		this.isCanceled = isCanceled;
		this.startTime = startTime;
		this.endTime = endTime;
		this.address1 = address1;
		this.address2 = address2;
		this.address3 = address3;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
	}

	public String getPartyId() {
		return partyId;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public float getCostMax() {
		return costMax;
	}

	public void setCostMax(float costMax) {
		this.costMax = costMax;
	}

	public int getIsCanceled() {
		return isCanceled;
	}

	public void setIsCanceled(int isCanceled) {
		this.isCanceled = isCanceled;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

}
