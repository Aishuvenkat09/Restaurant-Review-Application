//Joseph Triolo
//11/6/2019
//DBMS
//GoodFood Project

package goodfood.model;

public class Restaurants {
	protected String restaurantId;
	protected String restaurantName;
	protected String alias;
	protected float rating;
	protected String price;
	protected String phone;
	protected String address1;
	protected String address2;
	protected String address3;
	protected String city;
	protected String state;
	protected String country;
	protected String zip;
	
	public Restaurants(String restaurantId, String restaurantName, String alias, float rating, String price,
			String phone, String address1, String address2, String address3, String city, String state, String country,
			String zip) {
		this.restaurantId = restaurantId;
		this.restaurantName = restaurantName;
		this.alias = alias;
		this.rating = rating;
		this.price = price;
		this.phone = phone;
		this.address1 = address1;
		this.address2 = address2;
		this.address3 = address3;
		this.city = city;
		this.state = state;
		this.country = country;
		this.zip = zip;
	}
	
	public Restaurants(String restaurantId) {
		this.restaurantId = restaurantId;
	}
	
	public String getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(String restaurantId) {
		this.restaurantId = restaurantId;
	}
	public String getRestaurantName() {
		return restaurantName;
	}
	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}

}
