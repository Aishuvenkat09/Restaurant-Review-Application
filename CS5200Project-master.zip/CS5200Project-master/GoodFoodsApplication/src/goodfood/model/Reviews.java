
//Aishwarya Vantipuli




package goodfood.model;

import java.sql.Date;


public class Reviews {
	protected String reviewId;
	protected Date created;
	protected String content;
	protected int rating;
	protected Users user;
	protected Restaurants restaurant;
	
	public Reviews(String reviewId, String content, int rating,
			Users user,Restaurants  restaurant) {
		this.reviewId = reviewId;
		
		this.content = content;
		this.rating = rating;
		this.user = user;
		this.restaurant = restaurant;
	}
	
	public Reviews(String content, int rating,
			Users user,Restaurants  restaurant) {
		
		this.content = content;
		this.rating = rating;
		this.user = user;
		this.restaurant = restaurant;
	}
	
	public Reviews(String reviewId) {
		this.reviewId = reviewId;
	}
	
	public Reviews(Date created, int rating, Users user, Restaurants restaurant) {
		this.created = created;
		
		this.rating = rating;
		this.user = user;
		this.restaurant = restaurant;
	}

	public String getReviewId() {
		return reviewId;
	}

	public void setReviewId(String reviewId) {
		this.reviewId = reviewId;
	}
	
	
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}
		
	public Restaurants getRestaurant() {
			return restaurant;
		}

	public void setRestauraunt(Restaurants restaurant) {
		this.restaurant = restaurant;
	}
	
	
	
}
