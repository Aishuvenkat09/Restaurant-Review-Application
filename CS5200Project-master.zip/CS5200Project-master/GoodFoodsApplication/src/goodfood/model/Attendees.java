package goodfood.model;

/**
 * @Date : Nov 9, 2019
 *
 * @Author: Divyavijay Sahay
 */

public class Attendees {

	private Attending attending;
	private int userFK;
	private String partyFK;

	public enum Attending {
		YES, NO, MAYBE
	}

	public Attendees(Attending attending, int userFK, String partyFK) {
		super();
		this.attending = attending;
		this.userFK = userFK;
		this.partyFK = partyFK;
	}

	public Attending getAttending() {
		return attending;
	}

	public void setAttending(Attending attending) {
		this.attending = attending;
	}

	public int getUserFK() {
		return userFK;
	}

	public void setUserFK(int userFK) {
		this.userFK = userFK;
	}

	public String getPartyFK() {
		return partyFK;
	}

	public void setPartyFK(String partyFK) {
		this.partyFK = partyFK;
	}

}
