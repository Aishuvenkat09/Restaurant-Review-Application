//Aishwarya Vantipuli





package goodfood.model;


public class Users  {
	protected int UserId;
	protected String UserName;
	protected String Pword;
	protected String FirstName;
	protected String LastName;
	protected String Email;
	protected String Phone;
	


public Users( int UserId, String UserName,String Pword, String FirstName, String LastName,String Email,String Phone ) {
	this.UserId = UserId;
	this.UserName = UserName;
	this.Pword = Pword;
	this.FirstName = FirstName;
	this.LastName = LastName;
	this.Email = Email;
	this.Phone = Phone;
}
	
	public Users(String UserName,String Pword, String FirstName, String LastName, String Email , String Phone ) {
		
		this.UserName = UserName;
		this.Pword = Pword;
		this.FirstName = FirstName;
		this.LastName = LastName;
		this.Email = Email;
		this.Phone = Phone;
	}

	public Users(int UserId) {
		this.UserId = UserId;
	}
	
	public int  getUserId() {
		return UserId;
	}

	public void setUserId(int UserId) {
		this.UserId = UserId;
	
	}
	
	public String  getUserName() {
		return UserName;
	}

	public void setUserName(String UserName) {
		this.UserName = UserName;
	}
	
	public String getPword() {
		return Pword;
	}
	
	public  void setPassword(String Pword) {
		this.Pword = Pword;
	}

	public String getFirstName() {
		return FirstName;
	}
	
	public void setFirstName(String FirstName) {
		this.FirstName = FirstName;
	}
	public String getLastName() {
		return LastName;
	}
	
	public void setLastName(String LastName) {
		this.LastName = LastName;
	}
	public String getEmail() {
		return Email;
	}
	
	public void setEmail(String Email) {
		this.Email = Email;
	}
	public String getPhone() {
		return Phone;
	}
	
	public void setPhone(String Phone) {
		this.Phone = Phone;
	}
}
