import csv
from code import restaurant as res
from code import json_handler as json

DATA_PATH = "D:\\Work\\Neu\\sem4\\DB\\Project\\CS5200Project\\data"
DEFAULT_TERM = 'food'
LOCATIONS = ['Boston', 'San Francisco', 'New York', 'Las Vegas', 'Miami', 'Denver', 'Portland', 'Dallas', 'Los Angeles',
             'Chicago', 'Charleston', 'Seattle', 'Washington, D.C.', 'New Orleans', 'San Diego', 'St. Louis', 'Sedona',
             'Honolulu', 'Branson', 'Orlando']
# LOCATIONS = ['Nashville', 'San Antonio', 'Austin']


class App:
    restaurant = None
    json = None

    def __init__(self, restaurant, json):
        self.restaurant = restaurant
        self.json = json

    def load_credentials(self):
        path = DATA_PATH + "\\credentials.csv"
        rows = list(csv.reader(open(path), delimiter=','))
        return rows[0][1]

    def search(self, key, location, term):
        json_data = self.restaurant.get(key, term, location)
        print("Extraction completed for {}".format(location))
        return json_data

    def run(self):
        key = self.load_credentials()
        for location in LOCATIONS:
            data = self.search(key, location, DEFAULT_TERM)
            print("Saving data for {}".format(location))
            self.json.parse(data)
        self.json.close()


if __name__ == '__main__':
    app = App(res.RestaurantData(), json.JSON())
    app.run()
