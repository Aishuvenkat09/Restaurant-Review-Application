import csv
import json
import pprint

RESTAURANT_HEADER = ['id',
                     'name',
                     'Alias',
                     'rating',
                     'price',
                     'phone',
                     'address1',
                     'address2',
                     'address3',
                     'city',
                     'state',
                     'country',
                     'zip_code',
                     'CompanyFK', ]
CATEGORIES_HEADER = ['Alias',
                     'Title']
PICTURES_HEADER = ['PictureId',
                   'URL',
                   'RestaurantFK']

RESTAURANT_PATH = "restaurant.csv"
CATEGORIES_PATH = "categories.csv"
PICTURES_PATH = "pictures.csv"


class JSON:
    restaurant_file = None
    pictures_file = None
    categories_file = None
    restaurant_csv = None
    pictures_csv = None
    categories_csv = None

    def __init__(self):
        self.restaurant_file = open(RESTAURANT_PATH, 'a', newline='')
        self.pictures_file = open(PICTURES_PATH, 'a', newline='')
        self.categories_file = open(CATEGORIES_PATH, 'a', newline='')

        self.restaurant_csv = csv.writer(self.restaurant_file)
        self.pictures_csv = csv.writer(self.pictures_file)
        self.categories_csv = csv.writer(self.categories_file)

    def close(self):
        self.restaurant_file.close()
        self.pictures_file.close()
        self.categories_file.close()

    def parse_pictures(self, data, restaurant_id):
        for row in data:
            self.pictures_csv.writerow([row, restaurant_id])

    def parse_categories(self, data, restaurant_id):
        for row in data:
            self.categories_csv.writerow([row['alias'], row['title'], restaurant_id])

    def parse_restaurant(self, data, company_id):
        try:
            row = [data['id'], data['name'], data.get('alias'), data.get('rating'), data.get('price'),
                   data.get('phone'), data.get('location').get('address1'), data.get('location').get('address2'),
                   data.get('location').get('address3'), data.get('location').get('city'),
                   data.get('location').get('state'), data.get('location').get('country'),
                   data.get('location').get('zip_code'), company_id]
            self.restaurant_csv.writerow(row)
        except KeyError as err:
            print(err)
        except UnicodeEncodeError as err:
            print(err)
            print(data)

    def utfy_dict(self, dic):
        if isinstance(dic, str):
            return dic.encode('utf8')
        elif isinstance(dic, dict):
            for key in dic:
                dic[key] = self.utfy_dict(dic[key])
            return dic
        elif isinstance(dic, list):
            new_l = []
            for e in dic:
                new_l.append(self.utfy_dict(e))
            return new_l
        else:
            return dic

    def parse(self, city_data):
        company_id = 1
        for restaurant in city_data:
            try:
                r_id = restaurant['id']
            except KeyError as err:
                print(err)
                continue
            self.parse_restaurant(restaurant, company_id)
            self.parse_categories(restaurant['categories'], r_id)
            self.parse_pictures(restaurant['photos'], r_id)
            company_id = (company_id % 10) + 1
