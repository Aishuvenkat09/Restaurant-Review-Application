USE GoodFood;
 
# Restaurants with specific words Ex: cafe

SELECT RestaurantName, Price, city from restaurants
 where RestaurantName  like '%Cafe%' 
 limit 10;


 #Identifying price values for restaurants containing word cafe.

 SELECT RestaurantName ,
CASE
    WHEN  Price like '%$$$' THEN 'High'
    WHEN Price like '%$$' THEN 'Medium'
    WHEN  Price like '%$' THEN 'Low'
    else 'None'

END as PriceFactor

FROM restaurants
 where RestaurantName  like '%Cafe%'
 LIMIT 10;


#Highly recommended Restaurants in each city.
select (RestaurantName) , (city), count(*) as recommend_votes from restaurants 
inner join recommendations on recommendations.RestaurantFK = restaurants.RestaurantId
group by city, RestaurantName
order by recommend_votes desc
LIMIT 10;

#Users who gave rating 5 but doesnot recommend any restaurant
select reviews.UserFK , restaurants.RestaurantName from reviews inner join restaurants on restaurants.RestaurantId = reviews.RestaurantFK
where reviews.Rating = '5.0' 
and reviews.UserFK not in (select UserFK from recommendations)
order by UserFK;


