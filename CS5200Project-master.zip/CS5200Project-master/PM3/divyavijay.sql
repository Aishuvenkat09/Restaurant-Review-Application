#Insert queries for dummy data
#Party
insert into goodfood.parties(PartyId, PartyName, About, Cost, CostMax, IsCanceled, StartTime, EndTime, Address1, City, State, Country, Zip) 
values('p1', 'Halloween Bash', 'Halloween', 50, 100, false, '2019-12-01 05:00:00', '2019-12-01 10:00:00', 'St Germain', 'Boston', 'MA', 'USA', 02115);

insert into goodfood.parties(PartyId, PartyName, About, Cost, CostMax, IsCanceled, StartTime, EndTime, Address1, City, State, Country, Zip) 
values('p2', 'Candy Crush', 'Halloween', 15, 50, false, '2019-12-01 05:00:00', '2019-12-01 10:00:00', 'Boylston', 'Boston', 'MA', 'USA', 02115);

insert into goodfood.parties(PartyId, PartyName, About, Cost, CostMax, IsCanceled, StartTime, EndTime, Address1, City, State, Country, Zip) 
values('p3', 'Dance Night', 'Dance', 15, 50, false, '2019-12-04 05:00:00', '2019-12-04 10:00:00', 'Huntington Ave', 'Cambridge', 'MA', 'USA', 02115);

#User
insert into goodfood.users(UserName, Pword, FirstName, LastName, Email, Phone)
values('johns', 'j123', 'John', 'Snow', 'john@gmail.com', 1234567891);

insert into goodfood.users(UserName, Pword, FirstName, LastName, Email, Phone)
values('sas', 's123', 'Sam', 'Adam', 'sama@gmail.com', 6734567891);

insert into goodfood.users(UserName, Pword, FirstName, LastName, Email, Phone)
values('ram', 'asd2s', 'Ram', 'Singh', 'ramas@gmail.com', 3454567891);

#Attendees
insert into goodfood.attendees(Attending, UserFK, PartyFK) values('YES', 1, 'p1');
insert into goodfood.attendees(Attending, UserFK, PartyFK) values('YES', 2, 'p1');
insert into goodfood.attendees(Attending, UserFK, PartyFK) values('YES', 3, 'p1');
insert into goodfood.attendees(Attending, UserFK, PartyFK) values('YES', 2, 'p2');
insert into goodfood.attendees(Attending, UserFK, PartyFK) values('YES', 3, 'p2');

#1.	Search restaurants in an area based on Zipcode.
SELECT RestaurantName, Rating FROM goodfood.restaurants where zip = 94110 order by rating desc;

#2.	Search parties based in an area based on city/zipcode
SELECT * FROM goodfood.parties where city = 'Boston' and zip = 2115 order by cost;

#3.	Parties ordered by the total number of attendees or cost in the given city
SELECT 
    parties.PartyName, parties.About, parties.Cost, parties.CostMax, parties.StartTime, parties.EndTime, parties.City, X.count as `Total Attendees`
FROM
    goodfood.parties
        INNER JOIN
    (SELECT 
        PartyFK, COUNT(*) AS `count`
    FROM
        goodfood.attendees    
    GROUP BY partyFK) X ON parties.PartyId = X.partyFK
ORDER BY X.count DESC;



