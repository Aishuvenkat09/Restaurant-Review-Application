CREATE SCHEMA IF NOT EXISTS GoodFood;
USE GoodFood;

DROP TABLE IF EXISTS CategoryLinks;
DROP TABLE IF EXISTS Attendees;
DROP TABLE IF EXISTS Parties;
DROP TABLE IF EXISTS Reservations;
DROP TABLE IF EXISTS Recommendations;
DROP TABLE IF EXISTS Reviews;
DROP TABLE IF EXISTS Pictures;
DROP TABLE IF EXISTS Restaurants;
DROP TABLE IF EXISTS Categories;
DROP TABLE IF EXISTS Companies;
DROP TABLE IF EXISTS Users;

CREATE TABLE Users(
UserId INT AUTO_INCREMENT,
UserName VARCHAR(255) NOT NULL,
Pword VARCHAR(255) NOT NULL,
FirstName VARCHAR(255) NOT NULL,
LastName VARCHAR(255) NOT NULL,
Email VARCHAR(255) NOT NULL,
Phone VARCHAR(255) NOT NULL,
CONSTRAINT pk_Users_UserId PRIMARY KEY (UserId),
CONSTRAINT uq_Users_User UNIQUE(UserName)
);

CREATE TABLE Categories(
Alias VARCHAR(255),
Title VARCHAR(255),
CONSTRAINT pk_Categories_Title PRIMARY KEY (Title)
);

CREATE TABLE Restaurants(
RestaurantId VARCHAR(255),
RestaurantName VARCHAR(255) NOT NULL,
Alias VARCHAR(255),
Rating DECIMAL(2,1),
Price CHAR(4),
Phone VARCHAR(255),
Address1 VARCHAR(255),
Address2 VARCHAR(255),
Address3 VARCHAR(255),
City VARCHAR(255),
State CHAR(3),
Country VARCHAR(255),
Zip VARCHAR(255),
CONSTRAINT pk_Restaurants_RestaurantId PRIMARY KEY (RestaurantId)
);

CREATE TABLE CategoryLinks(
CategoryLinkId INT,
CategoryFK VARCHAR(255) NOT NULL,
RestaurantFK VARCHAR(255) NOT NULL,
CONSTRAINT pk_CategoryLinks_CategoryLinkId PRIMARY KEY (CategoryLinkId),
CONSTRAINT fk_CategoryLinks_Categories FOREIGN KEY (CategoryFK) REFERENCES
Categories(Title) ON UPDATE CASCADE ON DELETE CASCADE,
CONSTRAINT fk_CategoryLinks_Restaurants FOREIGN KEY (RestaurantFK) REFERENCES
Restaurants(RestaurantId) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Pictures(
URL VARCHAR(255),
RestaurantFK VARCHAR(255) NOT NULL,
CONSTRAINT pk_Pictures_URL PRIMARY KEY (URL),
CONSTRAINT fk_Picutres_RestaurantFK FOREIGN KEY (RestaurantFK) REFERENCES
Restaurants(RestaurantId) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Reviews(
ReviewId VARCHAR(255),
Content TEXT NOT NULL,
Rating INT NOT NULL,
UserFK INT NOT NULL,
RestaurantFK VARCHAR(255) NOT NULL,
CONSTRAINT pk_Reviews_ReviewId PRIMARY KEY (ReviewId),
CONSTRAINT fk_Reviews_Users FOREIGN KEY (UserFK) REFERENCES
Users(UserId) ON UPDATE CASCADE ON DELETE CASCADE,
CONSTRAINT fk_Reviews_Restaurants FOREIGN KEY (RestaurantFK) REFERENCES
Restaurants(RestaurantId) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Recommendations(
RecommendationId INT AUTO_INCREMENT,
UserFK INT NOT NULL,
RestaurantFK VARCHAR(255) NOT NULL,
CONSTRAINT pk_Recommendations_RecommendationId PRIMARY KEY (RecommendationId),
CONSTRAINT uq_Recommendations_Recommendation UNIQUE(UserFK, RestaurantFK),
CONSTRAINT fk_Recommendations_Users FOREIGN KEY (UserFK) REFERENCES
Users(UserId) ON UPDATE CASCADE ON DELETE CASCADE,
CONSTRAINT fk_Recommendations_Restaurants FOREIGN KEY (RestaurantFK) REFERENCES
Restaurants(RestaurantId) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Reservations(
ReservationId INT AUTO_INCREMENT,
Size INT NOT NULL,
StartTime TIMESTAMP NOT NULL,
EndTime TIMESTAMP NOT NULL,
UserFK INT NOT NULL,
RestaurantFK VARCHAR(255) NOT NULL,
CONSTRAINT pk_Reservations_ReservationId PRIMARY KEY (ReservationId),
CONSTRAINT fk_Reservations_Users FOREIGN KEY (UserFK) REFERENCES
Users(UserId) ON UPDATE CASCADE ON DELETE CASCADE,
CONSTRAINT fk_Reservations_Restaurants FOREIGN KEY (RestaurantFK) REFERENCES
Restaurants(RestaurantId) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Parties(
PartyId VARCHAR(255),
PartyName VARCHAR(255) NOT NULL,
About TEXT,
Cost DECIMAL(18,2),
CostMax DECIMAL(18,2),
IsCanceled BOOL,
StartTime TIMESTAMP,
EndTime TIMESTAMP,
Address1 VARCHAR(255),
Address2 VARCHAR(255),
Address3 VARCHAR(255),
City VARCHAR(255),
State CHAR(3),
Country VARCHAR(255),
Zip VARCHAR(255),
CONSTRAINT pk_Parties_PartyId PRIMARY KEY (PartyId)
);

CREATE TABLE Attendees(
AttendeeId INT AUTO_INCREMENT,
Attending ENUM('YES','NO','MAYBE') NOT NULL,
UserFK INT NOT NULL,
PartyFK VARCHAR(255) NOT NULL,
CONSTRAINT pk_Attendees_AttendeeId PRIMARY KEY (AttendeeId),
CONSTRAINT uq_Attendees_Attendee UNIQUE(UserFK, PartyFK),
CONSTRAINT fk_Attendees_Users FOREIGN KEY (UserFK) REFERENCES
Users(UserId) ON UPDATE CASCADE ON DELETE CASCADE,
CONSTRAINT fk_Attendees_Parties FOREIGN KEY (PartyFK) REFERENCES
Parties(PartyId) ON UPDATE CASCADE ON DELETE CASCADE
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/restaurant.csv' INTO TABLE Restaurants
CHARACTER SET latin1
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\r\n';

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/categories.csv' INTO TABLE Categories
CHARACTER SET latin1
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\r\n';

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/pictures.csv' INTO TABLE Pictures
CHARACTER SET latin1
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\r\n';

#SELECT URL, RestaurantFK FROM Pictures FULL JOIN Restaurants ON RestaurantFK=RestaurantId ORDER BY RestaurantFK;

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/category_link.csv' INTO TABLE CategoryLinks
CHARACTER SET latin1
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\r\n';

#SELECT CategoryLinkId, CategoryFK, RestaurantFK FROM CategoryLinks FULL JOIN Restaurants ON RestaurantFK=RestaurantId
#WHERE RestaurantFK = RestaurantId;

INSERT INTO Users (UserName, Pword, FirstName, LastName, Email, Phone)
VALUES ('jot', 'pass', 'joe', 't', 'joe.t@gmail.com', '1234567890');

INSERT INTO Users (UserName, Pword, FirstName, LastName, Email, Phone)
VALUES ('av', 'pass', 'a', 'v', 'a.v@gmail.com', '2345678901');

INSERT INTO Users (UserName, Pword, FirstName, LastName, Email, Phone)
VALUES ('dv', 'pass', 'd', 'v', 'd.v@gmail.com', '3456789012');

INSERT INTO Users (UserName, Pword, FirstName, LastName, Email, Phone)
VALUES ('pmd', 'pass', 'p', 'md', 'p.md@gmail.com', '4567890123');

INSERT INTO Users (UserName, Pword, FirstName, LastName, Email, Phone)
VALUES ('ta', 'pass', 't', 'a', 't.a@gmail.com', '5678901234');

INSERT INTO Reviews (ReviewId, Content, Rating, UserFK, RestaurantFK)
VALUES ('a1', 'Amazing food.', 5.0, 1, 'vGEeC43YdKPXREraMFWX3g');

INSERT INTO Reviews (ReviewId, Content, Rating, UserFK, RestaurantFK)
VALUES ('b2', 'Amazing food.', 5.0, 2, 'vGEeC43YdKPXREraMFWX3g');

INSERT INTO Reviews (ReviewId, Content, Rating, UserFK, RestaurantFK)
VALUES ('c3', 'Amazing food.', 5.0, 3, 'vGEeC43YdKPXREraMFWX3g');

INSERT INTO Reviews (ReviewId, Content, Rating, UserFK, RestaurantFK)
VALUES ('d4', 'Amazing food.', 5.0, 4, 'vGEeC43YdKPXREraMFWX3g');

INSERT INTO Reviews (ReviewId, Content, Rating, UserFK, RestaurantFK)
VALUES ('e5', 'Amazing food.', 5.0, 5, 'vGEeC43YdKPXREraMFWX3g');

INSERT INTO Reviews (ReviewId, Content, Rating, UserFK, RestaurantFK)
VALUES ('f6', 'Great Pizza.', 4.5, 1, '__I9HmtBMV4dDkEgT22V4g');

INSERT INTO Reviews (ReviewId, Content, Rating, UserFK, RestaurantFK)
VALUES ('g7', 'Great Gyros.', 4.5, 2, '4D16FWeW_fw3LCIdPRRbdQ');

INSERT INTO Reviews (ReviewId, Content, Rating, UserFK, RestaurantFK)
VALUES ('h8', 'Great Gyros.', 4.5, 3, '4D16FWeW_fw3LCIdPRRbdQ');

INSERT INTO Reviews (ReviewId, Content, Rating, UserFK, RestaurantFK)
VALUES ('i9', 'Great Seafood.', 4.5, 1, '58tSNgXpjAfDi8ZVlbr-Jw');

INSERT INTO Reviews (ReviewId, Content, Rating, UserFK, RestaurantFK)
VALUES ('j10', 'Great Grilled Cheese.', 4.0, 5, 'gxb1-SxUSEIskQg-nNcO-A');

insert into goodfood.parties(PartyId, PartyName, About, Cost, CostMax, IsCanceled, StartTime, EndTime, Address1, City, State, Country, Zip) 
values('p1', 'Halloween Bash', 'Halloween', 50, 100, false, '2019-12-01 05:00:00', '2019-12-01 10:00:00', 'St Germain', 'Boston', 'MA', 'USA', 02115);

insert into goodfood.parties(PartyId, PartyName, About, Cost, CostMax, IsCanceled, StartTime, EndTime, Address1, City, State, Country, Zip) 
values('p2', 'Candy Crush', 'Halloween', 15, 50, false, '2019-12-01 05:00:00', '2019-12-01 10:00:00', 'Boylston', 'Boston', 'MA', 'USA', 02115);

insert into goodfood.parties(PartyId, PartyName, About, Cost, CostMax, IsCanceled, StartTime, EndTime, Address1, City, State, Country, Zip) 
values('p3', 'Dance Night', 'Dance', 15, 50, false, '2019-12-04 05:00:00', '2019-12-04 10:00:00', 'Huntington Ave', 'Cambridge', 'MA', 'USA', 02115);

insert into goodfood.attendees(Attending, UserFK, PartyFK) values('YES', 1, 'p1');

insert into goodfood.attendees(Attending, UserFK, PartyFK) values('YES', 2, 'p1');

insert into goodfood.attendees(Attending, UserFK, PartyFK) values('YES', 3, 'p1');

insert into goodfood.attendees(Attending, UserFK, PartyFK) values('YES', 2, 'p2');

insert into goodfood.attendees(Attending, UserFK, PartyFK) values('YES', 3, 'p2');

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Users.csv' INTO TABLE users
CHARACTER SET latin1
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES
(UserId, UserName);

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/reviews.csv' INTO TABLE Reviews
CHARACTER SET latin1
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES
(ReviewId, Rating, UserFK, RestaurantFK);

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/recommendations.csv' INTO TABLE recommendations
CHARACTER SET latin1
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES;