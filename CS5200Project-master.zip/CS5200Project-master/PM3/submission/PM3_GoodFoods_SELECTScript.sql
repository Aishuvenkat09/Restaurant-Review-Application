USE GoodFood;
 
# 1. Restaurants with specific words Ex: cafe

SELECT RestaurantName, Price, city from restaurants
 where RestaurantName  like '%Cafe%' 
 limit 10;

 # 2. Identifying price values for restaurants containing word cafe.

  SELECT RestaurantName ,
CASE
    WHEN  Price like '%$$$' THEN 'High'
    WHEN Price like '%$$' THEN 'Medium'
    WHEN  Price like '%$' THEN 'Low'
    else 'None'

END as PriceFactor

FROM restaurants
 where RestaurantName  like '%Cafe%'
 LIMIT 10;

# 3. Highly recommended Restaurants in each city.
select (RestaurantName) , (city), count(*) as recommend_votes from restaurants 
inner join recommendations on recommendations.RestaurantFK = restaurants.RestaurantId
group by city, RestaurantName
order by recommend_votes desc
LIMIT 10;

# 4. Users who gave rating 5 but doesnot recommend
select reviews.UserFK , restaurants.RestaurantName from reviews inner join restaurants on restaurants.RestaurantId = reviews.RestaurantFK
where reviews.Rating = '5.0' 
and reviews.UserFK not in (select UserFK from recommendations)
order by UserFK;

#5.	Search restaurants in an area based on Zipcode.
SELECT RestaurantName, Rating FROM goodfood.restaurants where zip = 94110 order by rating desc;

#6.	Search parties based in an area based on city/zipcode
SELECT * FROM goodfood.parties where city = 'Boston' and zip = 2115 order by cost;

#7.	Parties ordered by the total number of attendees or cost in the given city
SELECT 
    parties.PartyName, parties.About, parties.Cost, parties.CostMax, parties.StartTime, parties.EndTime, parties.City, X.count as `Total Attendees`
FROM
    goodfood.parties
        INNER JOIN
    (SELECT 
        PartyFK, COUNT(*) AS `count`
    FROM
        goodfood.attendees    
    GROUP BY partyFK) X ON parties.PartyId = X.partyFK
ORDER BY X.count DESC;

# 8. What is the count for each category? Order by average rating for each category and only show categories with a count > 40.

SELECT CategoryLinks.CategoryFK, AVG(Restaurants.Rating) AS CategoryRating, COUNT(CategoryLinks.CategoryFK) AS CategoryCount
FROM Restaurants
INNER JOIN CategoryLinks ON Restaurants.RestaurantId = CategoryLinks.RestaurantFK
GROUP BY CategoryFK
HAVING CategoryCount > 40
ORDER BY CategoryRating DESC, CategoryCount DESC;

# 9. What is the information for the restaurant with the most 5 star reviews?

SELECT RestaurantName, Price, Restaurants.Rating, COUNT(ReviewId) AS ReviewCount
FROM Reviews
INNER JOIN Restaurants ON Restaurants.RestaurantId = Reviews.RestaurantFK
GROUP BY Reviews.Rating, RestaurantFK
HAVING Reviews.Rating = 5
ORDER BY ReviewCount DESC
LIMIT 1;

# 10. What is the ratio of number of reviews to number of pictures? Include relevant information for restaurants and order by restaurant rating and ratio result.

SELECT RestaurantName, Price, RestaurantData.Rating, ReviewCount, PictureCount, ReviewCount/PictureCount AS ReviewsToPicturesRatio FROM
(SELECT *, COUNT(RestaurantFK) AS ReviewCount
FROM Reviews
GROUP BY RestaurantFK) AS ReviewGroups
INNER JOIN
(SELECT *, COUNT(RestaurantFK) AS PictureCount
FROM Pictures
GROUP BY RestaurantFK) AS PictureGroups
ON ReviewGroups.RestaurantFK = PictureGroups.RestaurantFK
INNER JOIN
(SELECT RestaurantId, RestaurantName, Rating, Price
FROM Restaurants) AS RestaurantData
ON ReviewGroups.RestaurantFK = RestaurantData.RestaurantId
ORDER BY Rating DESC, ReviewsToPicturesRatio DESC;